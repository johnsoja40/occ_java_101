/*
   name:       Jamie Johnson
   Assignment: CIS1500Test2 Loops
   Problem:    1
*/

public class Test2_1
{
  public static void main(String[] args)
  {
  for (int x = 28; x >=7; x -=7)
  	System.out.printf("%d\n",x);
  }
}
